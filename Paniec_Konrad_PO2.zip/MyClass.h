#pragma once
class MyClass
{

public:
	BITMAPFILEHEADER header;
	LPVOID obrazInfo;
	LPVOID obrazBajty;
	LPVOID obrazKolory;
	DWORD sizeOfFile;
	int typeOfImage;
	int fileWidth = 0, fileHeight = 0;
	float* histogram;

	MyClass();
	~MyClass();

	//LAB1
	bool LoadDIB(CString sciezka_do_pliku);
	bool PaintDIB(HDC kontekst, CRect r);
	bool CreateGreyscaleDIB(CRect rozmiar_obrazu, int xPPM, int yPPM);
	bool GetPixel1(int x, int y);
	BYTE GetPixel8(int x, int y);
	RGBTRIPLE GetPixel24(int x, int y);
	bool SetPixel8(int x, int y, BYTE val);
	bool SaveDIB(CString sciezka_do_pliku);

	//LAB2
	void ChangeBrightness(float value);
	void ChangeKontrast(float value);
	void ChangePotega(float value);
	void Negatyw();
	void CalculateHistogram(int startX, int startY, int endX, int endY); // baza do histogramow
	void ShowHistogram();
	void WyrownajHistogram();
};

